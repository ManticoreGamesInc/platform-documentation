================================================================================
-- Install plugins for corresponding Editor --
--------------------------------------------------------------------------------

For Atom:
Install atom packages language-lua and autocomplete-lua:

https://atom.io/packages/language-lua
https://atom.io/packages/autocomplete-lua


For VSCode:
Install extensions vscode-lua and LuaCoderAssist

https://marketplace.visualstudio.com/items?itemName=trixnz.vscode-lua
https://marketplace.visualstudio.com/items?itemName=liwangqian.luacoderassist

In Settings -> Extensions -> Lua Coder Assist, disable "code metric codelens"

--------------------------------------------------------------------------------

Copy .luacompleterc file to Platform/Saved/Maps folder, or the parent directory where content files are stored.
