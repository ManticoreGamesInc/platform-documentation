================================================================================
-- Install Plugins for corresponding Editor --
--------------------------------------------------------------------------------

For Atom:

Install Atom packages language-lua and autocomplete-lua:

https://atom.io/packages/language-lua
https://atom.io/packages/autocomplete-lua


For Visual Studio Code:

Install extensions vscode-lua and LuaCoderAssist

https://marketplace.visualstudio.com/items?itemName=trixnz.vscode-lua
https://marketplace.visualstudio.com/items?itemName=liwangqian.luacoderassist

In Settings -> Extensions -> Lua Coder Assist, disable "code metric codelens"

--------------------------------------------------------------------------------

You need to add the folder containing `.luacompleterc` to the library settings of the Lua Language Server extension.
To do this, open up the VS Code settings via CTRL + SHIFT + P, type "Open Settings (JSON)" and hit enter.

Now add the following to the end:

"Lua.workspace.library": { "C:\\Users\\YOURUSERNAME\\Documents\\My Games\\Core\\Saved\\Maps": true },
"Lua.diagnostics.enable": false,

We are setting Lua diagnostics to `false` since we are going to use the Luacheck integration that comes with VSCode-Lua.

You need to open your project in VS Code directly, not via double-clicking the script file in Core, otherwise autocomplete will not work.