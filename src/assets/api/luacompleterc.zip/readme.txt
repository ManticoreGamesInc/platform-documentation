================================================================================
-- Install Plugins for Corresponding Editor --
--------------------------------------------------------------------------------

For Atom:

Install Atom packages language-lua and autocomplete-lua:

https://atom.io/packages/language-lua
https://atom.io/packages/autocomplete-lua


For Visual Studio Code:

Install extensions vscode-lua and LuaCoderAssist

https://marketplace.visualstudio.com/items?itemName=trixnz.vscode-lua
https://marketplace.visualstudio.com/items?itemName=liwangqian.luacoderassist

In Settings -> Extensions -> Lua Coder Assist, disable "code metric codelens"

--------------------------------------------------------------------------------

Copy .luacompleterc file to Platform/Saved/Maps folder, or the parent directory where content files are stored.

Note for Visual Studio Code:

You need to add the folder containing `.luacompleterc` to the library settings of the Lua Language Server extension.

Example: `"Lua.workspace.library": {"C:\\Users\\Manti\\Documents\\My Games\\Core\\Saved\\Maps": true}`
